package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FindRidesGUI extends JFrame {
    private static final long serialVersionUID = 1L;

    private JTable ridesTable;
    private JButton selectRideButton, closeButton;

    public FindRidesGUI() {
        setTitle("Find Available Rides");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Modelo de la tabla
        String[] columnNames = {"Driver", "Start Location", "End Location", "Time", "Capacity"};
        Object[][] rideData = {
            {"John Doe", "New York", "Boston", "2025-03-10 10:00", 3},
            {"Jane Smith", "Los Angeles", "San Francisco", "2025-03-11 15:30", 2},
            {"Mark Lee", "Chicago", "Detroit", "2025-03-12 09:45", 4}
        };

        DefaultTableModel tableModel = new DefaultTableModel(rideData, columnNames);
        ridesTable = new JTable(tableModel);
        ridesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // ScrollPane para la tabla
        JScrollPane scrollPane = new JScrollPane(ridesTable);
        add(scrollPane, BorderLayout.CENTER);

        // Panel inferior con botones
        JPanel buttonPanel = new JPanel();
        selectRideButton = new JButton("Select Ride");
        closeButton = new JButton("Close");

        // Acción al seleccionar un viaje
        selectRideButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectRide();
            }
        });

        // Acción para cerrar la ventana
        closeButton.addActionListener(e -> dispose());

        buttonPanel.add(selectRideButton);
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void selectRide() {
        int selectedRow = ridesTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a ride!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String driver = (String) ridesTable.getValueAt(selectedRow, 0);
        String startLocation = (String) ridesTable.getValueAt(selectedRow, 1);
        String endLocation = (String) ridesTable.getValueAt(selectedRow, 2);
        String time = (String) ridesTable.getValueAt(selectedRow, 3);
        int capacity = (int) ridesTable.getValueAt(selectedRow, 4);

        JOptionPane.showMessageDialog(this,
            "Ride Selected:\nDriver: " + driver +
            "\nFrom: " + startLocation +
            "\nTo: " + endLocation +
            "\nTime: " + time +
            "\nSeats Available: " + capacity,
            "Ride Details", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(FindRidesGUI::new);
    }
}
