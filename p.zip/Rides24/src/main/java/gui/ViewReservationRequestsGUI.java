package gui;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ViewReservationRequestsGUI extends JFrame {
    private static final long serialVersionUID = 1L;

    private JList<String> reservationRequestsList;
    private JButton closeButton;

    public ViewReservationRequestsGUI() {
        setTitle("Reservation Requests");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Lista de solicitudes de reserva (para este ejemplo, se agregan de manera manual)
        List<String> reservationRequests = new ArrayList<>();
        reservationRequests.add("Request 1: Client - John Doe, Date - 2025-03-09");
        reservationRequests.add("Request 2: Client - Jane Smith, Date - 2025-03-10");
        reservationRequests.add("Request 3: Client - Mark Lee, Date - 2025-03-12");

        // Crear un modelo de lista y asignarlo al JList
        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (String request : reservationRequests) {
            listModel.addElement(request);
        }

        reservationRequestsList = new JList<>(listModel);
        reservationRequestsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        reservationRequestsList.setLayoutOrientation(JList.VERTICAL);
        reservationRequestsList.setVisibleRowCount(10);

        // Colocar la lista dentro de un JScrollPane
        JScrollPane scrollPane = new JScrollPane(reservationRequestsList);
        add(scrollPane, BorderLayout.CENTER);

        // Botón para cerrar la ventana
        closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        add(closeButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewReservationRequestsGUI());
    }
}