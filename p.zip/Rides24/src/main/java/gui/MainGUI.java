package gui;

/**
 * @author Software Engineering teachers
 */



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainGUI extends JFrame {
    private static final long serialVersionUID = 1L;
    private Map<String, String> usersDatabase = new HashMap<>();
    private Map<String, String> userRoles = new HashMap<>(); // Guarda si es "Driver" o "Client"
    private JPanel jContentPane;
    private JButton jButtonCreateQuery, jButtonQueryQueries, jButtonViewReservationRequests;
    
    public MainGUI() {
        super();
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Login & Registration");
        jContentPane = new JPanel();
        jContentPane.setLayout(new GridLayout(4, 1, 10, 10));

        // Botón para registrar conductores
        JButton btnRegisterDriver = new JButton("Register as Driver");
        btnRegisterDriver.addActionListener(e -> new RegisterDriverGUI().setVisible(true));

        // Botón para registrar clientes
        JButton btnRegisterClient = new JButton("Register as Client");
        btnRegisterClient.addActionListener(e -> new RegisterClientGUI().setVisible(true));

        // Botón para iniciar sesión
        JButton btnLogin = new JButton("Login");
        btnLogin.addActionListener(e -> new LoginGUI().setVisible(true));

        jContentPane.add(btnRegisterDriver);
        jContentPane.add(btnRegisterClient);
        jContentPane.add(btnLogin);
        setContentPane(jContentPane);
    }

    // Registro de conductores
    class RegisterDriverGUI extends JFrame {
        private JTextField nameField, emailField;
        private JButton submitButton;

        public RegisterDriverGUI() {
            setTitle("Register Driver");
            setSize(300, 200);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(new GridLayout(3, 2, 10, 10));

            add(new JLabel("Name:"));
            nameField = new JTextField();
            add(nameField);

            add(new JLabel("Email:"));
            emailField = new JTextField();
            add(emailField);

            submitButton = new JButton("Submit");
            submitButton.addActionListener(e -> registerDriver());
            add(submitButton);
        }

        private void registerDriver() {
            String name = nameField.getText();
            String email = emailField.getText();

            if (!name.isEmpty() && !email.isEmpty()) {
                usersDatabase.put(email, name);
                userRoles.put(email, "Driver");
                JOptionPane.showMessageDialog(this, "Driver registered successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            }
        }
    }

    // Registro de clientes
    class RegisterClientGUI extends JFrame {
        private JTextField nameField, emailField;
        private JButton submitButton;

        public RegisterClientGUI() {
            setTitle("Register Client");
            setSize(300, 200);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(new GridLayout(3, 2, 10, 10));

            add(new JLabel("Name:"));
            nameField = new JTextField();
            add(nameField);

            add(new JLabel("Email:"));
            emailField = new JTextField();
            add(emailField);

            submitButton = new JButton("Submit");
            submitButton.addActionListener(e -> registerClient());
            add(submitButton);
        }

        private void registerClient() {
            String name = nameField.getText();
            String email = emailField.getText();

            if (!name.isEmpty() && !email.isEmpty()) {
                usersDatabase.put(email, name);
                userRoles.put(email, "Client");
                JOptionPane.showMessageDialog(this, "Client registered successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            }
        }
    }

    // Login
    class LoginGUI extends JFrame {
        private JTextField emailField, nameField;
        private JButton loginButton;

        public LoginGUI() {
            setTitle("Login");
            setSize(300, 200);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(new GridLayout(3, 2, 10, 10));

            add(new JLabel("Email:"));
            emailField = new JTextField();
            add(emailField);

            add(new JLabel("Name:"));
            nameField = new JTextField();
            add(nameField);

            loginButton = new JButton("Login");
            loginButton.addActionListener(e -> login());
            add(loginButton);
        }

        private void login() {
            String email = emailField.getText();
            String name = nameField.getText();

            if (!email.isEmpty() && !name.isEmpty()) {
                if (usersDatabase.containsKey(email) && usersDatabase.get(email).equals(name)) {
                    JOptionPane.showMessageDialog(this, "Login successful!");
                    String role = userRoles.get(email);
                    showDashboard(role);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Incorrect email or name.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            }
        }
    }

    // Muestra opciones extra si el usuario es "Driver"
    private void showDashboard(String role) {
        jContentPane.removeAll();
        jContentPane.setLayout(new GridLayout(5, 1, 10, 10));

        JLabel welcomeLabel = new JLabel("Welcome, " + role + "!", SwingConstants.CENTER);
        jContentPane.add(welcomeLabel);

        if (role.equals("Driver")) {
            jButtonCreateQuery = new JButton("Create Ride");
            jButtonCreateQuery.addActionListener(e -> new CreateRideGUI().setVisible(true));

            jButtonQueryQueries = new JButton("Query Rides");
            jButtonQueryQueries.addActionListener(e -> new FindRidesGUI().setVisible(true));

            jButtonViewReservationRequests = new JButton("View Reservation Requests");
            jButtonViewReservationRequests.addActionListener(e -> new ViewReservationRequestsGUI().setVisible(true));

            jContentPane.add(jButtonCreateQuery);
            jContentPane.add(jButtonQueryQueries);
            jContentPane.add(jButtonViewReservationRequests);
        }

        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> resetToLogin());
        jContentPane.add(logoutButton);

        jContentPane.revalidate();
        jContentPane.repaint();
    }

    private void resetToLogin() {
        jContentPane.removeAll();
        jContentPane.setLayout(new GridLayout(4, 1, 10, 10));

        JButton btnRegisterDriver = new JButton("Register as Driver");
        btnRegisterDriver.addActionListener(e -> new RegisterDriverGUI().setVisible(true));

        JButton btnRegisterClient = new JButton("Register as Client");
        btnRegisterClient.addActionListener(e -> new RegisterClientGUI().setVisible(true));

        JButton btnLogin = new JButton("Login");
        btnLogin.addActionListener(e -> new LoginGUI().setVisible(true));

        jContentPane.add(btnRegisterDriver);
        jContentPane.add(btnRegisterClient);
        jContentPane.add(btnLogin);

        jContentPane.revalidate();
        jContentPane.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI().setVisible(true));
    }
}
// @jve:decl-index=0:visual-constraint="0,0"

