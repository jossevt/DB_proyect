package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class CreateRideGUI extends JFrame {
    private static final long serialVersionUID = 1L;

    private JTextField startLocationField, endLocationField, capacityField, timeField;
    private JButton createRideButton, cancelButton;

    public CreateRideGUI() { // Constructor sin Driver
        // Configuración de la ventana
        setTitle("Create a Ride");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(6, 2, 10, 10));

        // Etiquetas y campos de texto para cada detalle del viaje
        JLabel startLocationLabel = new JLabel("Start Location:");
        startLocationField = new JTextField();
        JLabel endLocationLabel = new JLabel("End Location:");
        endLocationField = new JTextField();
        JLabel timeLabel = new JLabel("Time (YYYY-MM-DD HH:MM):");
        timeField = new JTextField();
        JLabel capacityLabel = new JLabel("Capacity:");
        capacityField = new JTextField();

        // Botón para crear el viaje
        createRideButton = new JButton("Create Ride");
        createRideButton.addActionListener(this::createRide);

        // Botón para cancelar y cerrar la ventana
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose()); // Cierra la ventana si se cancela

        // Agregar componentes al layout
        add(startLocationLabel);
        add(startLocationField);
        add(endLocationLabel);
        add(endLocationField);
        add(timeLabel);
        add(timeField);
        add(capacityLabel);
        add(capacityField);
        add(createRideButton);
        add(cancelButton);

        setVisible(true);
    }

    // Método para crear el viaje
    private void createRide(ActionEvent e) {
        String startLocation = startLocationField.getText();
        String endLocation = endLocationField.getText();
        String time = timeField.getText();
        String capacity = capacityField.getText();

        // Validar los campos antes de crear el viaje
        if (startLocation.isEmpty() || endLocation.isEmpty() || time.isEmpty() || capacity.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int capacityInt = Integer.parseInt(capacity);
            JOptionPane.showMessageDialog(this, "Ride created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose(); // Cerrar la ventana después de crear el viaje
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Capacity must be a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
