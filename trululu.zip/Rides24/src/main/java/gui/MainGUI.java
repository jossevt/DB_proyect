package gui;

/**
 * @author Software Engineering teachers
 */


import javax.swing.*;

import businessLogic.BLFacade;
import domain.Driver;

import java.awt.*;
import java.awt.event.*;

public class MainGUI extends JFrame {
    private static final long serialVersionUID = 1L;
    
    private Driver driver;
    private Client client;
    
    public MainGUI(Driver driver, Client client) {
        this.driver = driver;
        this.client = client;

        // Configura la interfaz
        setTitle("Main Menu");
        setSize(600, 400);
        setLayout(new FlowLayout());

        // Agregar botones y funcionalidades basadas en el rol del usuario
        if (driver != null) {
            JButton btnCreateTrip = new JButton("Crear Viaje");
            btnCreateTrip.addActionListener(e -> openCreateTripGUI());
            add(btnCreateTrip);
            
            JButton btnQueryTrips = new JButton("Consultar Viajes");
            btnQueryTrips.addActionListener(e -> openQueryTripsGUI());
            add(btnQueryTrips);
        }

        if (client != null) {
            JButton btnReserveTrip = new JButton("Reservar Viaje");
            btnReserveTrip.addActionListener(e -> openReserveTripGUI());
            add(btnReserveTrip);
        }

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar la ventana
    }

    private void openCreateTripGUI() {
        new CreateTripGUI(driver.getEmail()).setVisible(true);  // Abre la interfaz de creación de viajes
    }

    private void openReserveTripGUI() {
        new ReserveTripGUI().setVisible(true);  // Abre la interfaz de reserva de viajes
    }

    private void openQueryTripsGUI() {
        new QueryTripsGUI().setVisible(true);  // Abre la interfaz de consulta de viajes
    }
}// @jve:decl-index=0:visual-constraint="0,0"

