package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginGUI extends JFrame {
    private JTextField textFieldEmail;
    private JTextField textFieldName;
    private JButton btnLogin;

    public LoginGUI() {
        setTitle("Login");
        setSize(400, 200);
        setLayout(new GridLayout(3, 1));

        // Panel para el correo electrónico
        JPanel panelEmail = new JPanel();
        panelEmail.add(new JLabel("Email:"));
        textFieldEmail = new JTextField(15);
        panelEmail.add(textFieldEmail);
        add(panelEmail);

        // Panel para el nombre
        JPanel panelName = new JPanel();
        panelName.add(new JLabel("Nombre:"));
        textFieldName = new JTextField(15);
        panelName.add(textFieldName);
        add(panelName);

        // Botón para iniciar sesión
        btnLogin = new JButton("Iniciar Sesión");
        btnLogin.addActionListener(e -> loginUser());
        add(btnLogin);

        // Configurar la operación de cierre
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private void loginUser() {
        String email = textFieldEmail.getText();
        String name = textFieldName.getText();
        // Lógica de inicio de sesión aquí
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginGUI().setVisible(true));
    }
}
